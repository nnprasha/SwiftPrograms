//
//  InformationViewController.swift
//  ShuttleServiceApp
//
//  Created by Nikhil Prashar on 11/30/16.
//  Copyright © 2016 Nikhil Prashar. All rights reserved.
//

import UIKit
class InformationViewController: UIViewController{
    
   
    @IBOutlet var name_textf: UITextField!
    @IBOutlet var suid_textf: UITextField!
    @IBOutlet var address_textf: UITextField!
    @IBOutlet var time_textf: UITextField!
    
    var name:String!
    var address:String!
    var suid:String!
    var time:String!
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)        
        print("name: \(name)\n address: \(address)\n suid: \(suid)\ntime:\(time)")
        name_textf.text = name
        suid_textf.text = suid
        address_textf.text = address
        time_textf.text = time
    }
   /* override func viewDidLoad() {
        print("name: \(name)\n address: \(address)\n suid: \(suid)\ntime:\(time)")
        address_tv.text = address
        name_tv.text = name
        suid_tv.text = suid
        time_tv.text = time
    }*/    
}
