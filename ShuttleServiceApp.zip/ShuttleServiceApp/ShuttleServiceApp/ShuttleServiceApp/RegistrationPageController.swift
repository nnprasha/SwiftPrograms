//
//  RegistrationPageController.swift
//  ShuttleServiceApp
//
//  Created by Nikhil Prashar on 11/25/16.
//  Copyright © 2016 Nikhil Prashar. All rights reserved.
//
import UIKit

class RegistrationPageController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {
    
    // The sample values
    var values = ["10:30", "11:00", "11:30", "12:00", "12:30", "1:00", "1:30", "2:00", "2:30", "3:00", "3:30"]
    var valuesForAddress :[String] = []
    let cellReuseIdentifier = "cell"
    
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    
    // Using simple subclass to prevent the copy/paste menu
    // This is optional, and a given app may want a standard UITextField
    @IBOutlet var textField: UITextField!
    @IBOutlet var suid_TextField: UITextField!
    @IBOutlet var textField_Address: UITextField!
    @IBOutlet var name_TextField:UITextField!
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet var registerButton: UIButton!
    
    var regItemStore = RegisteredItemStore()
    
    func showSuccessAlert()
    {
        let ac = UIAlertController(title: "Registration Successful",
                                   message: "SMS has been sent",
                                   preferredStyle: .ActionSheet)
        
        
        let newGameAction = UIAlertAction(title: "OK",
                                          style: .Default ,
                                          handler: { (action) -> Void in
                                            self.viewDidLoad()
        })
        ac.addAction(newGameAction)
        
        presentViewController(ac, animated: true, completion: nil)
    }
    
    func showErrorAlert(msg: String)
    {
        let ac = UIAlertController(title: "Error",
                                   message: msg,
                                   preferredStyle: .ActionSheet)
        
        
        let newGameAction = UIAlertAction(title: "OK",
                                          style: .Default ,
                                          handler: { (action) -> Void in
                                            self.viewDidLoad()
        })
        ac.addAction(newGameAction)
        
        presentViewController(ac, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        
        tableView.delegate = self
        tableView.dataSource = self
        textField.delegate = self
        
        tableView.hidden = true
        suid_TextField.delegate = self
        
        // Manage tableView visibility via TouchDown in textField
        textField.addTarget(self, action: #selector(textFieldActive), forControlEvents: UIControlEvents.TouchDown)
        
        
    }
    
    override func viewDidDisappear(animated: Bool) {
        super.viewDidDisappear(animated)
        
        regItemStore.saveChanges()
    }
    
    func textField(textField_checker: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        if (textField_checker == textField){
            return false
        }
        else if (textField_checker == suid_TextField)
        {
            // only 0-9 allowed
            let maxLength = 9
            let currentString: NSString = suid_TextField.text!
            let newString: NSString = currentString.stringByReplacingCharactersInRange(range, withString: string)
            if (newString.length > maxLength){
                return false // if max length it will always return false
            }
            
            let allowedValues = NSCharacterSet(charactersInString:"0123456789").invertedSet
            let compSepByCharInSet = string.componentsSeparatedByCharactersInSet(allowedValues)
            let result = compSepByCharInSet.joinWithSeparator("")
            return string == result
        }
        return false
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func Register_buttonClicked(sender: AnyObject) {
        
        if(regItemStore.allRegisteredItems.count > 0)
        {
            for item in regItemStore.allRegisteredItems
            {
                if(item.suid == Int(suid_TextField.text!)! && item.time == textField.text!)
                {
                    showErrorAlert("Duplicate value. \(suid_TextField.text!) already registerred for \(textField.text!)")
                    return
                }
            }
            if(name_TextField.text != "" && suid_TextField.text != "" && textField_Address.text != "" && textField.text != "")
            {
                let regItem = RegisterItem(name: name_TextField.text!,suid: Int(suid_TextField.text!)!,time: textField.text!,address: textField_Address.text!)
                regItemStore.addItem(regItem)
                showSuccessAlert()
            }
            else{
                showErrorAlert("Please Enter All Details")
            }
        }
        else{
            let regItem = RegisterItem(name: name_TextField.text!,suid: Int(suid_TextField.text!)!,time: textField.text!,address: textField_Address.text!)
            regItemStore.addItem(regItem)
            showSuccessAlert()
        }
        
    }
    
    @IBAction func UserTappedTheBackground(gestureRecogniser: UITapGestureRecognizer)
    {
        suid_TextField.resignFirstResponder()
        name_TextField.resignFirstResponder()
        textField.resignFirstResponder()
        textField_Address.resignFirstResponder()
    }
    
    // Manage keyboard and tableView visibility
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?)
    {
        guard let touch:UITouch = touches.first else
        {
            return;
        }
        if touch.view != tableView
        {
            textField.endEditing(true)
            tableView.hidden = true
        }
    }
    
    // Toggle the tableView visibility when click on textField
    func textFieldActive() {
        tableView.hidden = !tableView.hidden
    }
    
    // MARK: UITextFieldDelegate
    func textFieldDidEndEditing(textField: UITextField) {
        // TODO: Your app can do something when textField finishes editing
        print("The textField ended editing. Do something based on app requirements.")
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return values.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:UITableViewCell = tableView.dequeueReusableCellWithIdentifier("cell") as UITableViewCell!
        // Set text from the data model
        cell.textLabel?.text = values[indexPath.row]
        cell.textLabel?.font = textField.font
        return cell
    }
    
    // MARK: UITableViewDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        // Row selected, so set textField to relevant value, hide tableView
        // endEditing can trigger some other action according to requirements
        textField.text = values[indexPath.row]
        tableView.hidden = true
        textField.endEditing(true)
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.0
    }
}
