//
//  LoginPage.swift
//  ShuttleServiceApp
//
//  Created by Nikhil Prashar on 11/24/16.
//  Copyright © 2016 Nikhil Prashar. All rights reserved.
//

import UIKit
class LoginPage: UIViewController{
    
  
    @IBOutlet var netIdTextField: UITextField?
    @IBOutlet var passwordTextField: UITextField?
    @IBOutlet var login: UIButton?
    
    var username = ["nnprasha","parora01","asrana","kkohli"]
    var password = ["abc@123","abc@123","abc@123","abc@123"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }    
    
    func showErrorAlert()
    {
        let ac = UIAlertController(title: "Error",
                                   message: "Incorrect Credentials",
                                   preferredStyle: .ActionSheet)
        
        
        let newGameAction = UIAlertAction(title: "OK",
                                          style: .Default ,
                                          handler: { (action) -> Void in
                                            self.viewDidLoad()
        })
        ac.addAction(newGameAction)
        
        presentViewController(ac, animated: true, completion: nil)
    }
    
    @IBAction func LoginButton(button : UIButton)
    {
        var uIndex: Int?
        
        var flag: Int = 0
        if let a = netIdTextField!.text
        {
            for item in username {
                if item == a
                {
                    uIndex = username.indexOf(item)
                    flag = 1
                    break
                }
            }
            if(flag == 1)
            {
                if passwordTextField!.text == password[uIndex!]
                {
                    self.performSegueWithIdentifier("NavigateToReg", sender: self)
                }
                else{
                    showErrorAlert()
                }
            }
            else
            {
               showErrorAlert()
            }
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        print("seagueued")
    }
    @IBAction func UserTappedTheBackground(gestureRecogniser: UITapGestureRecognizer)
    {
        netIdTextField?.resignFirstResponder()
        passwordTextField?.resignFirstResponder()
    }
}