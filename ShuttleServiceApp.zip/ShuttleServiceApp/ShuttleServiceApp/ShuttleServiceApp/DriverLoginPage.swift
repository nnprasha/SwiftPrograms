//
//  LoginPage.swift
//  ShuttleServiceApp
//
//  Created by Nikhil Prashar on 11/24/16.
//  Copyright © 2016 Nikhil Prashar. All rights reserved.
//

import UIKit
class DriverLoginPage: UIViewController{
    
    
    @IBOutlet var driverIdTextField: UITextField?
    @IBOutlet var passwordTextField: UITextField?
    @IBOutlet var login: UIButton?
    
    var username = ["driver1","driver2","driver3"]
    var password = ["abc@123","abc@123","abc@123"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func showErrorAlert()
    {
        let ac = UIAlertController(title: "Error",
                                   message: "Incorrect Credentials",
                                   preferredStyle: .ActionSheet)
        
        
        let newGameAction = UIAlertAction(title: "OK",
                                          style: .Default ,
                                          handler: { (action) -> Void in
                                            self.viewDidLoad()
        })
        ac.addAction(newGameAction)
        
        presentViewController(ac, animated: true, completion: nil)
    }
    
    @IBAction func LoginButton(button : UIButton)
    {
        var uIndex: Int?
        
        var flag: Int = 0
        if let a = driverIdTextField!.text
        {
            for item in username {
                if item == a
                {
                    uIndex = username.indexOf(item)
                    flag = 1
                    break
                }
            }
            if(flag == 1)
            {
                if passwordTextField!.text == password[uIndex!]
                {
                    self.performSegueWithIdentifier("NavigateToShowRegistrations", sender: self)
                }
                else{
                    showErrorAlert()
                }
            }
            else
            {
                showErrorAlert()
            }
        }
    }
    
    @IBAction func UserTappedTheBackground(gestureRecogniser: UITapGestureRecognizer)
    {
        driverIdTextField?.resignFirstResponder()
        passwordTextField?.resignFirstResponder()
    }
}