//
//  DriverPageController.swift
//  ShuttleServiceApp
//
//  Created by Nikhil Prashar on 11/28/16.
//  Copyright © 2016 Nikhil Prashar. All rights reserved.
//

import UIKit



class HeadingCell:UITableViewCell{
    @IBOutlet var headingLabel: UILabel!
    @IBOutlet var suid_heading: UILabel!
    @IBOutlet var time_heading: UILabel!
}

class ItemCell: UITableViewCell{
    @IBOutlet var time: UILabel!
    @IBOutlet var suid: UILabel!
}

//class ItemStore{
//    var listOfCells = [ItemCell]()
//}

class DriverPageController: UITableViewController {
   
    var noofRowsInSection: [Int] = [1]
    //var itemStore =  ItemStore()
    var regItemStore =  RegisteredItemStore()
    
    override func viewDidLoad() {
        super.viewDidLoad()     
    }

    // MARK: - Table view data source
    
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        //return RegisterItem.sectionBasedOntime.count
        return 1
    }
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
      //  return noofRowsInSection[section]
        return  regItemStore.allRegisteredItems.count + 2
    }
    
   /*override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return RegisterItem.sectionBasedOntime[section]
    }*/
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {        
        let vc = segue.destinationViewController as! InformationViewController
        
        if (segue.identifier == "NavigateToInfo")
        {
            if let row = tableView.indexPathForSelectedRow?.row{
                print("row***: \(row)")
                let item = regItemStore.allRegisteredItems[row-2]
               // vc.name = "HI"
               // vc.address = "HI"
                let selectedSuid = item.suid
                let selectedTime = item.time
                vc.suid = String(selectedSuid)
                vc.time = selectedTime
                
                var indexCount = -1
                
                for regItem in regItemStore.allRegisteredItems
                {
                    indexCount = indexCount + 1
                    if(selectedSuid == regItem.suid)
                    {
                        if(regItem.time == selectedTime)
                        {
                            vc.name = regItem.name
                            vc.address = regItem.address
                            break
                        }
                    }
                }
            }
        }
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        print("indexpathrow: \(indexPath.row)")
        if indexPath.row == 0
        {
            let hc = tableView.dequeueReusableCellWithIdentifier("HeadingCell", forIndexPath: indexPath) as! HeadingCell
            hc.headingLabel.text = "Registrations"
            return hc
        }
            
        else if indexPath.row == 1
        {
            let hc = tableView.dequeueReusableCellWithIdentifier("ItemHeadingCell", forIndexPath: indexPath) as! HeadingCell
            hc.suid_heading.text = "SUID"
            hc.time_heading.text = "TIME"
            hc.suid_heading.font = UIFont.boldSystemFontOfSize(16)
            hc.time_heading.font = UIFont.boldSystemFontOfSize(16)
            return hc
        }
        
        let contentCell = tableView.dequeueReusableCellWithIdentifier("ItemCell", forIndexPath: indexPath) as! ItemCell
        contentCell.suid.text = String(regItemStore.allRegisteredItems[indexPath.row - 2].suid)
        contentCell.time.text = regItemStore.allRegisteredItems[indexPath.row - 2].time
        return contentCell
    }
    
    /*
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath)

        // Configure the cell...

        return cell
    }
    */
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */
    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */
    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */
    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
