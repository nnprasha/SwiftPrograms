//
//  TicTacToeViewController.swift
//  GameZ
//
//  Created by Nikhil Prashar on 10/28/16.
//  Copyright © 2016 Nikhil Prashar. All rights reserved.
//
import UIKit

class TicTacToeViewController: UIViewController {
    
    //game is an instance of TicTacToeBrain
    var game = TicTacToeBrain()
    
    
    //"buttons" is an array of IBOutlets
    //The first buttion connected to "buttons" will be connected to the first array location, 
    //the second button connected to "buttons" will be connected to the secondary array location, and so on.
    @IBOutlet var buttons: [UIButton]!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        startNewGame()
    }
    
    //Function that changes the colour of the buttons to green whenever there is a winner
    func buttonColorChange(i1: Int,i2: Int,i3: Int)
    {
        buttons[i1].setTitleColor(UIColor.greenColor(), forState: .Normal)
        buttons[i2].setTitleColor(UIColor.greenColor(), forState: .Normal)
        buttons[i3].setTitleColor(UIColor.greenColor(), forState: .Normal)
    }
      
    
    //IBAction for buttons. All 9 buttons invoke this IBAction.
    @IBAction func buttonPressed(button: UIButton) {
        
            var playerID : Int?
        
            //Checking if the button is already pressed or not
            if(!game.buttonAlreadyPressed(button.tag))
            {
                button.setTitleColor(UIColor.whiteColor(), forState: .Normal)
                game.whichButonPressed(button.tag)
                if game.playerIdentity == 1
                {
                    button.setTitle("X", forState: .Normal)
                    
                }
                else{
                    button.setTitle("O", forState: .Normal)
                }
                
                let arr: [Int] = game.compute() //calling compute that returns the winner
                if(arr.count != 0 || game.drawChecker == 1)
                {
                    if arr.count == 3
                    {
                        buttonColorChange(arr[0], i2: arr[1], i3: arr[2])
                        playerID = game.playerIdentity
                    }                    
                    gameOverWithWinner(playerID)
                }
                
            }
            else
            {
                return
            }
        
    }    
    
    //gameOverWithWinner(playerID: Int?) will need to be invoked when the game is over with the identity of
    //the winning player. If there is no winner, the function is called with nil (i.e., the function takes as input an Optional Int).
    //The function creates an UIAlertAction to notify the user of the game outcome along with
    //providing the option to start a new game
    func gameOverWithWinner(playerID: Int?) {
        
        let title = "Game Over"
        var message = String()
        
        if let ID = playerID {
             message = "Player \(ID) wins"
        }
        else {
             message = "No Winner"
        }
        
        let ac = UIAlertController(title: title,
                                   message: message,
                                   preferredStyle: .ActionSheet)
        
        let newGameAction = UIAlertAction(title: "New Game",
                                          style: .Default ,
                                          handler: { (action) -> Void in
                                           self.startNewGame()
                            })
        ac.addAction(newGameAction)
        
        presentViewController(ac, animated: true, completion: nil)
    }
    
    //startNewGame() resets the game state 
    func startNewGame() {
        
        game.resetGame()
        
        for i in 0...8 {
            buttons[i].setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
            buttons[i].setTitle("", forState: .Normal)
        }
        
        //button tags
        buttons[0].tag=00
        buttons[1].tag=01
        buttons[2].tag=02
        buttons[3].tag=10
        buttons[4].tag=11
        buttons[5].tag=12
        buttons[6].tag=20
        buttons[7].tag=21
        buttons[8].tag=22
    }
    
    
}
