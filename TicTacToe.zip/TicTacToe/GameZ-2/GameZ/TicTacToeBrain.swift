//
//  TicTacToeBrain.swift
//  GameZ
//
//  Created by Nikhil Prashar on 10/28/16.
//  Copyright © 2016 Nikhil Prashar. All rights reserved.
//

import UIKit

class TicTacToeBrain {

    //the game board as a 2D array
    //the board is intialized to all zeroes
    //each cell of the board can be made to store the playerIdentity (i.e., 1 or 2) depending on which player occupies that cell.
    var board = [[0, 0, 0],
                 [0, 0, 0],
                 [0, 0, 0]]
    
    
    //playerIdentity is the identity of the current player.
    //playerIdentity is intially set to 1 (for player playing "X")
    //playerIdentity will toggle between 1 (for player playing "X") and 2 (for player playing "O")
    var playerIdentity: Int = 1
    
    //DrawChecker check whether the game has drawn
    var drawChecker : Int?
    
    //resetGame() resets the game state
    func resetGame() {
        
        board = [[0, 0, 0],
                 [0, 0, 0],
                 [0, 0, 0]]
        
       playerIdentity = 1
       drawChecker = 0
        
    }
    
    //identifies which button is pressed
    func whichButonPressed(tag: Int)
    {
        board[tag/10][tag%10] = playerIdentity
    }
    
    //checks if one of the buttons is already pressed or not
    func buttonAlreadyPressed(tag: Int) -> Bool
    {
        if(board[tag/10][tag%10] == 0)
        {
            return false
        }
        else{
            return true
        }
    }
    
    //Function
    func compute() -> [Int]
    {
        let arr: [Int] = winnerCheck()
        if(arr.count != 0 || drawChecker == 1)
        {
            if(drawChecker != 1)
            {
                return arr
            }
            else{
                return []
            }
            
        }
        else{
            if(playerIdentity == 1)
            {
                playerIdentity = 2
                return []
            }
            else{
                playerIdentity = 1
                return []
            }
        }
    }
    //Checks for the winner
    func winnerCheck() -> [Int]
    {
        
        //--------Horizontal check------------
        if (board[0] == [playerIdentity,playerIdentity,playerIdentity])
        {
            return [0,1,2]  //Returns tags of the buttons whose colour has to be changed
        }
        if board[1] == [playerIdentity,playerIdentity,playerIdentity]
        {
            return [3,4,5]
        }
        if board[2] == [playerIdentity,playerIdentity,playerIdentity]
        {
            return [6,7,8]
        }
        
        //----------Vertical Check-------------
        if (board[0][0] == playerIdentity && board[1][0] == playerIdentity && board[2][0] == playerIdentity)
        {
            return [0,3,6]
        }
        if (board[0][1] == playerIdentity && board[1][1] == playerIdentity && board[2][1] == playerIdentity)
        {
            return [1,4,7]
        }
        if (board[0][2] == playerIdentity && board[1][2] == playerIdentity && board[2][2] == playerIdentity)
        {
            return [2,5,8]
        }
        
        //---------diagnol check--------------
        if (board[0][0] == playerIdentity && board[1][1] == playerIdentity && board[2][2] == playerIdentity)
        {
            return [0,4,8]
        }
        if (board[0][2] == playerIdentity && board[1][1] == playerIdentity && board[2][0] == playerIdentity)
        {
            return [2,4,6]
        }
        
        //----------Draw Check----------------
        if( board[0][0] != 0 && board[0][1] != 0 && board[0][2] != 0 && board[1][0] != 0 && board[1][1] != 0 && board[1][2] != 0 && board[2][0] != 0 && board[2][1] != 0 && board[2][2] != 0)
        {
            drawChecker = 1
        }
        
        return []
    }
    
}
