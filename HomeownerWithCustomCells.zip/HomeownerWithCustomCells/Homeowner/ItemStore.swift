//
//  ItemStore.swift
//  Homeowner
//
//  Created by teacher on 10/18/16.
//  Copyright © 2016 Syracuse University. All rights reserved.
//

import UIKit

class ItemStore {
    var allItems = [[Item]](count:2, repeatedValue:[Item]()) //2d Array to store data (0->Cheap, 1->Expensive)
    
    //function to create an item
    func createItem() -> Item {
        let newItem = Item(random: true)
        
        if(newItem.valueInDollars<50)
        {
            allItems[0].append(newItem)
        }
        else{
            allItems[1].append(newItem)
        }
        
        //allItems.insert(newItem, atIndex: 0)
        
        return newItem
    }
    
    //function to remove specified item from the array
    func removeItem(item: Item) {
        if(item.valueInDollars < 50)
        {
            if let index = allItems[0].indexOf(item) {
                allItems[0].removeAtIndex(index)
            }
        }
        else{
            if let index = allItems[1].indexOf(item) {
                allItems[1].removeAtIndex(index)
            }
        }
        
    }
    
    //function to reorder an item in the array
    func moveItem(fromIndex: Int, toIndex: Int, section:Int) {
        
        if fromIndex == toIndex {
            return
        }
        
        let movedItem = allItems[section][fromIndex]
        
        allItems[section].removeAtIndex(fromIndex)
        
        allItems[section].insert(movedItem, atIndex: toIndex)
        
    }
    
    //function to print all items in the array
    func printAllItems() {
       // for i in 0...4 {
      //      print("name: \(allItems[i].name) value: \(allItems[i].valueInDollars) SN: \(allItems[i].serialNumber)")
       // }
    }
}
