//
//  LastCell.swift
//  Homeowner
//
//  Created by Nikhil Prashar on 11/16/16.
//  Copyright © 2016 Syracuse University. All rights reserved.
//

import UIKit

//LastCell is a custom cell
class LastCell: UITableViewCell {
    
    @IBOutlet var nameLabel: UILabel!
    
}