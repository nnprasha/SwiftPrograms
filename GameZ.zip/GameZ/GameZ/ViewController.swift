//
//  ViewController.swift
//  GameZ
//
//  Created by Nikhil Prashar on 10/11/16.
//  Copyright © 2016 Nikhil Prashar. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var expressionLabel: UILabel?
    @IBOutlet var textField: UITextField?
    @IBOutlet weak var answer: UILabel?
    var number1: Int?
    var number2: Int?
    let arithmeticArray = ["+","-","*"]
    var selectedOperation: String?
    var soln:Int?
    var answerLabel: String?
    
    
    var answerEnterred: Int?
    {
        didSet{
            computeAnswer() //called when answerEnterred is given a value
        }
    }
    
    // Function called when the play button is pressed
    @IBAction func playButton(button: UIButton)
    {
        button.setTitle("PLAY AGAIN", forState: .Normal)
        
        answer!.text = ""
        textField!.text = ""
        
        settingExpressionLabel() //sets the expression on the expression label
        
    }
    
    //Function that computes the value of the expression enterred
    func computeAnswer()
    {
        answerLabel = "INCORRECT"
        
        switch selectedOperation! {
        case "+":
            soln = number1!+number2!
            if answerEnterred == soln
            {
                answerLabel = "CORRECT"
            }
            
        case "-":
            soln = number1!-number2!
            if answerEnterred == soln
            {
                answerLabel = "CORRECT"
            }
            
        case "*":
            soln = number1!*number2!
            if answerEnterred == soln
            {
                answerLabel = "CORRECT"
            }
            
        default:
            answerLabel = ""
            
        }

    }
    
    //Function that sets the expression label
    func settingExpressionLabel()
    {
        number1 = Int(arc4random_uniform(10))
        
        number2 = Int(arc4random_uniform(10))
    
        let randomIndex = Int(arc4random_uniform(UInt32(arithmeticArray.count)))
    
        let char = arithmeticArray[randomIndex]
    
        expressionLabel!.text = String(number1!) + String(char) + String(number2!)
        
        selectedOperation = char
        
    }
    
    //Function Called whenever any change is made on the text field
    @IBAction func textFieldModifier(textField: UITextField) {
        if let value=Int(textField.text!)
        {
            answerEnterred = value  //answerEnterred get the value enterred at the text field
        }
        else
        {
            answer!.text = ""
        }
    }
    
    //function called when the submit button is pressed
    @IBAction func submitFunction(button: UIButton)
    {
        if(textField!.text != "")
        {
            assignFontColor()  //function called that assings "correct" or "incorrect"  value
        }
        else
        {
                answer!.text = ""
        }
        
    }
    
    //functions assigns correct or incorrect and sets the color respectively
    func assignFontColor()
    {
        if(answerLabel == "CORRECT")
        {
            answer!.textColor = UIColor.greenColor()
        }
        else
        {
            answer!.textColor = UIColor.redColor()
        }
        answer!.text = answerLabel
    }
    
    //IBAction for UITapGestureRecognizer, used when user clicks the background
    @IBAction func userTappedTheBackground(gestureRecognizer: UITapGestureRecognizer) {
        textField!.resignFirstResponder()
       
        if(textField!.text != "")
        {
            assignFontColor()
        }
        else
        {
            answer!.text = ""
        }
        
    }
    
    //Delegate used when user presses the return key on the keyboard
    func textFieldShouldReturn(textField: UITextField) -> Bool {   //delegate method
        textField.resignFirstResponder()
        if(textField.text != "")
        {
            assignFontColor()
        }
        else
        {
            answer!.text = ""
        }
        return true
    }
    
    //Delegate used to check if the first number enterred is 0 or no.
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        computeAnswer()
        if soln == 0
        {
           return true
        }
        let existingText = textField.text!
        if existingText == ""
        {
            let newText = string
            if(Int(newText) == 0)
            {
                return false
            }
        }
        
        return true
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        settingExpressionLabel()
        computeAnswer()
        answer!.text = ""
        
        textField!.delegate = self
        
    }
        

}

